CREATE FUNCTION trigger_before_u_seminar_users() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.su_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_seminar_users() OWNER TO webapp;

