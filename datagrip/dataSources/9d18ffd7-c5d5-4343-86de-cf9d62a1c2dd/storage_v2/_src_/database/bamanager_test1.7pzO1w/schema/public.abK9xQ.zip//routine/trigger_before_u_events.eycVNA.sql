CREATE FUNCTION trigger_before_u_events() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.event_revision = nextval('revision_seq');
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_events() OWNER TO webapp;

