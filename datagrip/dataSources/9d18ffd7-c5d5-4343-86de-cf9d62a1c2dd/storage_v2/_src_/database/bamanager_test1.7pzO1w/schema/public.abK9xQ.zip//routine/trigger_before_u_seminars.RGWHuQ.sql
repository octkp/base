CREATE FUNCTION trigger_before_u_seminars() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.seminar_revision = nextval('revision_seq');
	NEW.seminar_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_seminars() OWNER TO webapp;

