CREATE FUNCTION trigger_after_iu_company_partner_escalation_results() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	-- @formatter:off
	INSERT INTO updated_items (ui_unique_code,ui_revision) VALUES (NEW.cper_unique_code, NEW.cper_revision) on CONFLICT (ui_unique_code,ui_revision) do NOTHING;
	-- @formatter:on
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_after_iu_company_partner_escalation_results() OWNER TO webapp;

