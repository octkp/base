CREATE VIEW view_ba_company_service_offer_categories
			( bacso_category_id, bacso_category_seq, bacso_category_short_name, bacso_category_description
			, bacso_category_code
			) AS
SELECT
	bacso_category_id
  , bacso_category_data ->> 'cso_category_seq'::TEXT         AS bacso_category_seq
  , bacso_category_data ->> 'cso_category_short_name'::TEXT  AS bacso_category_short_name
  , bacso_category_data ->> 'cso_category_description'::TEXT AS bacso_category_description
  , bacso_category_data ->> 'cso_category_code'::TEXT        AS bacso_category_code
FROM ba_company_service_offer_categories;

ALTER TABLE view_ba_company_service_offer_categories
	OWNER TO webapp;

GRANT SELECT ON view_ba_company_service_offer_categories TO koko_readonly_role2;

GRANT SELECT ON view_ba_company_service_offer_categories TO data_platform_readonly_role;

