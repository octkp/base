CREATE FUNCTION trigger_before_u_partner_informations() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.pi_revision = nextval('revision_seq');
	NEW.pi_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_partner_informations() OWNER TO webapp;

