CREATE VIEW view_company_cso_count(company_unique_code, company_coupon_count, company_coupon_site_count) AS
SELECT
	companies.company_unique_code
  , t_cso.company_coupon_count
  , t_cso.company_coupon_site_count
FROM companies
LEFT JOIN (SELECT
	           company_service_offers.cso_company_unique_code AS company_unique_code
             , count(*)                                       AS company_coupon_count
             , sum(t_csos.csos_count)                         AS company_coupon_site_count
           FROM company_service_offers
           LEFT JOIN company_service_offer_statuses USING (cso_status)
           LEFT JOIN (SELECT
	                      company_service_offer_sites.csos_cso_unique_code AS cso_unique_code
                        , count(*)                                         AS csos_count
                      FROM company_service_offer_sites
                      WHERE company_service_offer_sites.csos_is_deleted = 0
                      GROUP BY company_service_offer_sites.csos_cso_unique_code) t_csos USING (cso_unique_code)
           WHERE company_service_offer_statuses.cso_is_published = 1
	         AND company_service_offers.cso_limit_date >= CURRENT_DATE
           GROUP BY company_service_offers.cso_company_unique_code) t_cso USING (company_unique_code);

ALTER TABLE view_company_cso_count
	OWNER TO webapp;

GRANT SELECT ON view_company_cso_count TO koko_readonly_role2;

GRANT SELECT ON view_company_cso_count TO data_platform_readonly_role;

