CREATE VIEW view_joseikin_areas(ji_id, ji_area_pref_code, ji_area_name) AS
SELECT
	joseikin_items.ji_id
  , prefectures.pref_code AS ji_area_pref_code
  , j_area.area_name      AS ji_area_name
FROM joseikin_items
CROSS JOIN LATERAL ( SELECT
	                     jsonb_array_elements_text.value AS area_name
                     FROM jsonb_array_elements_text(joseikin_items.ji_area_list) jsonb_array_elements_text(value)) j_area
LEFT JOIN prefectures ON prefectures.pref_name = j_area.area_name;

ALTER TABLE view_joseikin_areas
	OWNER TO webapp;

GRANT SELECT ON view_joseikin_areas TO koko_readonly_role2;

GRANT SELECT ON view_joseikin_areas TO data_platform_readonly_role;

