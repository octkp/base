CREATE MATERIALIZED VIEW view_company_business_types AS
WITH RECURSIVE r AS (SELECT
	                     company_business_types.cbt_id
                       , company_business_types.cbt_code
                       , 0                                       AS cbt_depth
                       , company_business_types.cbt_id::TEXT     AS cbt_id_path_string
                       , ARRAY [company_business_types.cbt_id]   AS cbt_id_path_array
                       , company_business_types.cbt_code         AS cbt_code_path_string
                       , ARRAY [company_business_types.cbt_code] AS cbt_code_path_array
                       , company_business_types.cbt_name         AS cbt_name_path
                       , ARRAY [company_business_types.cbt_name] AS cbt_name_path_array
                     FROM company_business_types
                     WHERE company_business_types.cbt_parent_code IS NULL
                     UNION ALL
                     SELECT
	                     company_business_types.cbt_id
                       , company_business_types.cbt_code
                       , r_1.cbt_depth + 1                                                                         AS cbt_depth
                       , (r_1.cbt_id_path_string || '.'::TEXT) ||
                         COALESCE(company_business_types.cbt_id::TEXT, ''::TEXT)                                   AS cbt_id_path_string
                       , r_1.cbt_id_path_array || ARRAY [company_business_types.cbt_id]                            AS cbt_id_path_array
                       , (r_1.cbt_code_path_string || '.'::TEXT) ||
                         COALESCE(company_business_types.cbt_code, ''::TEXT)                                       AS cbt_code_path_string
                       , r_1.cbt_code_path_array || ARRAY [company_business_types.cbt_code]                        AS cbt_code_path_array
                       , (r_1.cbt_name_path || ' > '::TEXT) ||
                         COALESCE(company_business_types.cbt_name, ''::TEXT)                                       AS cbt_name_path
                       , r_1.cbt_name_path_array || ARRAY [company_business_types.cbt_name]                        AS cbt_name_path_array
                     FROM company_business_types, r r_1
                     WHERE company_business_types.cbt_parent_code = r_1.cbt_code)
SELECT
	cbt_id
  , cbt_code
  , cbt_depth
  , cbt_id_path_string
  , cbt_id_path_array
  , cbt_code_path_string
  , cbt_code_path_array
  , cbt_name_path
  , cbt_name_path_array
  , cbt_code_path_array[1] AS company_cbt_1_code
  , cbt_name_path_array[1] AS company_cbt_1_name
  , cbt_code_path_array[2] AS company_cbt_2_code
  , cbt_name_path_array[2] AS company_cbt_2_name
FROM r;

ALTER MATERIALIZED VIEW view_company_business_types OWNER TO webapp;

GRANT SELECT ON view_company_business_types TO koko_readonly_role2;

GRANT SELECT ON view_company_business_types TO data_platform_readonly_role;

