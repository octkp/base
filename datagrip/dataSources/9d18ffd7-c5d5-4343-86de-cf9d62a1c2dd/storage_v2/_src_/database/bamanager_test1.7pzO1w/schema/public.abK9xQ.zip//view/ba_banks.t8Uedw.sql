CREATE VIEW ba_banks
			( babank_id, babank_created_at, babank_updated_at, babank_original_updated_at, babank_unique_code
			, babank_code, babank_revision, babank_is_disabled, babank_name, babank_data, babank_hold_on_production
			)
AS
SELECT
	bank_id                 AS babank_id
  , bank_created_at         AS babank_created_at
  , bank_updated_at         AS babank_updated_at
  , bank_updated_at         AS babank_original_updated_at
  , bank_unique_code        AS babank_unique_code
  , bank_code               AS babank_code
  , bank_revision           AS babank_revision
  , 0                       AS babank_is_disabled
  , bank_name               AS babank_name
  , to_jsonb(banks.*)       AS babank_data
  , bank_hold_on_production AS babank_hold_on_production
FROM banks;

ALTER TABLE ba_banks
	OWNER TO webapp;

GRANT SELECT ON ba_banks TO koko_readonly_role2;

GRANT SELECT ON ba_banks TO data_platform_readonly_role;

