CREATE FUNCTION trigger_before_u_user_new_ca_notifications() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.uncn_updated_at = now();
	
	IF old.uncn_search_conditions IS DISTINCT FROM new.uncn_search_conditions
	THEN
		new.uncn_search_conditions_updated_at = now();
	END IF;
	IF old.uncn_actual_search_conditions IS DISTINCT FROM new.uncn_actual_search_conditions
	THEN
		new.uncn_actual_search_conditions_updated_at = now();
	END IF;
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_user_new_ca_notifications() OWNER TO webapp;

