CREATE FUNCTION trigger_after_d_files() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	INSERT INTO
		deleted_files
	(
	file_unique_code, file_bank_code, file_deleted_data
	)
	VALUES
	(
	OLD.file_unique_code, OLD.file_bank_code, to_jsonb(OLD)
	);
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_after_d_files() OWNER TO webapp;

