CREATE FUNCTION earth_distance(earth, earth) RETURNS double precision
	IMMUTABLE
	STRICT
	PARALLEL SAFE
	LANGUAGE sql
AS
$$SELECT sec_to_gc(cube_distance($1, $2))$$;

ALTER FUNCTION earth_distance(EARTH, EARTH) OWNER TO rdsadmin;

