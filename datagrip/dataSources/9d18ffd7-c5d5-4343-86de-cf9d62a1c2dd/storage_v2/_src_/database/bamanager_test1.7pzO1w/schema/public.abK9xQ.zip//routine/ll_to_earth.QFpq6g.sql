CREATE FUNCTION ll_to_earth(double precision, double precision) RETURNS earth
	IMMUTABLE
	STRICT
	PARALLEL SAFE
	LANGUAGE sql
AS
$$SELECT cube(cube(cube(earth()*cos(radians($1))*cos(radians($2))),earth()*cos(radians($1))*sin(radians($2))),earth()*sin(radians($1)))::earth$$;

ALTER FUNCTION ll_to_earth(DOUBLE PRECISION, DOUBLE PRECISION) OWNER TO rdsadmin;

