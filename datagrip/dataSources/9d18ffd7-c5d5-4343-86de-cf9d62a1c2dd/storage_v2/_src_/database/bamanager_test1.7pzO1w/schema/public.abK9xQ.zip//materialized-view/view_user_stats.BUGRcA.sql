CREATE MATERIALIZED VIEW view_user_stats AS
SELECT
	users.user_bank_code
  , user_types.user_type_group
  , companies.company_type
  , companies.company_bb_unique_code
  , users.user_type
  , count(*)                  AS count
  , GROUPING(users.user_bank_code, user_types.user_type_group, companies.company_type, companies.company_bb_unique_code,
             users.user_type) AS "grouping"
FROM users
JOIN user_types USING (user_type)
LEFT JOIN companies ON users.user_company_unique_code = companies.company_unique_code
LEFT JOIN company_statuses USING (company_status)
WHERE users.user_is_disabled = 0
  AND COALESCE(company_statuses.company_is_disabled, 0) = 0
GROUP BY CUBE (users.user_bank_code, user_types.user_type_group, companies.company_type
       , companies.company_bb_unique_code, users.user_type);

ALTER MATERIALIZED VIEW view_user_stats OWNER TO webapp;

CREATE INDEX view_user_stats_company_bb_unique_code_idx
	ON view_user_stats(company_bb_unique_code);

CREATE INDEX view_user_stats_company_type_idx
	ON view_user_stats(company_type);

CREATE INDEX view_user_stats_user_type_group_idx
	ON view_user_stats(user_type_group);

CREATE INDEX view_user_stats_user_type_idx
	ON view_user_stats(user_type);

GRANT SELECT ON view_user_stats TO koko_readonly_role2;

GRANT SELECT ON view_user_stats TO data_platform_readonly_role;

