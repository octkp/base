CREATE FUNCTION trigger_before_u_banks() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.bank_revision = nextval('revision_seq');
	NEW.bank_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_banks() OWNER TO webapp;

