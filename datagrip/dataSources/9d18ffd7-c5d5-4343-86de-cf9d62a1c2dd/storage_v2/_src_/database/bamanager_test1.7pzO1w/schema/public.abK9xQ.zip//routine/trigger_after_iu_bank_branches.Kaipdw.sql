CREATE FUNCTION trigger_after_iu_bank_branches() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	-- @formatter:off
	INSERT INTO updated_items (ui_unique_code,ui_revision) VALUES (NEW.bb_unique_code, NEW.bb_revision) on CONFLICT (ui_unique_code,ui_revision) do NOTHING;
	-- @formatter:on
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_after_iu_bank_branches() OWNER TO webapp;

