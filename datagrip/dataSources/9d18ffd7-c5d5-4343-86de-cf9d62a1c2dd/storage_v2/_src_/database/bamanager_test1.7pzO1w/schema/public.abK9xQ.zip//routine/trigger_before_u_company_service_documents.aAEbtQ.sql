CREATE FUNCTION trigger_before_u_company_service_documents() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.csd_revision = nextval('revision_seq');
	NEW.csd_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_company_service_documents() OWNER TO webapp;

