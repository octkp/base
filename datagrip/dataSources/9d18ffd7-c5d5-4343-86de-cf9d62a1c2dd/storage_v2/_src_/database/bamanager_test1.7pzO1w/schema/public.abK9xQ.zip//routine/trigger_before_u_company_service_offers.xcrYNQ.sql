CREATE FUNCTION trigger_before_u_company_service_offers() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.cso_revision = nextval('revision_seq');
	NEW.cso_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_company_service_offers() OWNER TO webapp;

