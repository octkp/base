CREATE FUNCTION earth_box(earth, double precision) RETURNS cube
	IMMUTABLE
	STRICT
	PARALLEL SAFE
	LANGUAGE sql
AS
$$SELECT cube_enlarge($1, gc_to_sec($2), 3)$$;

ALTER FUNCTION earth_box(EARTH, DOUBLE PRECISION) OWNER TO rdsadmin;

