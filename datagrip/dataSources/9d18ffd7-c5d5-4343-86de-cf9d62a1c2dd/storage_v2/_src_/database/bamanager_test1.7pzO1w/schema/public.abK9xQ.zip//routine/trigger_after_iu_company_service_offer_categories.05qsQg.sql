CREATE FUNCTION trigger_after_iu_company_service_offer_categories() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	-- @formatter:off
	INSERT INTO updated_items (ui_unique_code,ui_revision) VALUES (NEW.cso_category_unique_code, NEW.cso_category_revision) on CONFLICT (ui_unique_code,ui_revision) do NOTHING;
	-- @formatter:on
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_after_iu_company_service_offer_categories() OWNER TO webapp;

