CREATE FUNCTION trigger_before_u_company_service_offer_categories() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.cso_category_revision = nextval('revision_seq');
	NEW.cso_category_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_company_service_offer_categories() OWNER TO webapp;

