CREATE MATERIALIZED VIEW view_cmh_stats_delete_test_20250513 AS
SELECT
	view_company_matching_histories.cmh_requester_bank_code
  , view_company_matching_histories.cmh_requester_bb_unique_code
  , company_matching_histories.cmh_destination_bank_code
  , view_company_matching_histories.cmh_destination_bb_unique_code
  , company_matching_histories.cmh_status
  , count(*)                                                                                                        AS count
  , GROUPING(view_company_matching_histories.cmh_requester_bank_code,
             view_company_matching_histories.cmh_requester_bb_unique_code,
             company_matching_histories.cmh_destination_bank_code,
             view_company_matching_histories.cmh_destination_bb_unique_code,
             company_matching_histories.cmh_status)                                                                 AS "grouping"
FROM company_matching_histories
JOIN view_company_matching_histories USING (cmh_unique_code)
GROUP BY CUBE (view_company_matching_histories.cmh_requester_bank_code
       , view_company_matching_histories.cmh_requester_bb_unique_code
       , company_matching_histories.cmh_destination_bank_code
       , view_company_matching_histories.cmh_destination_bb_unique_code, company_matching_histories.cmh_status);

ALTER MATERIALIZED VIEW view_cmh_stats_delete_test_20250513 OWNER TO webapp;

CREATE INDEX view_cmh_stats_cmh_destination_bank_code_idx
	ON view_cmh_stats_delete_test_20250513(cmh_destination_bank_code);

CREATE INDEX view_cmh_stats_cmh_destination_bb_unique_code_idx
	ON view_cmh_stats_delete_test_20250513(cmh_destination_bb_unique_code);

CREATE INDEX view_cmh_stats_cmh_requester_bank_code_idx
	ON view_cmh_stats_delete_test_20250513(cmh_requester_bank_code);

CREATE INDEX view_cmh_stats_cmh_requester_bb_unique_code_idx
	ON view_cmh_stats_delete_test_20250513(cmh_requester_bb_unique_code);

GRANT SELECT ON view_cmh_stats_delete_test_20250513 TO koko_readonly_role2;

GRANT SELECT ON view_cmh_stats_delete_test_20250513 TO data_platform_readonly_role;

