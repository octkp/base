CREATE FUNCTION trigger_after_iud_ba_data() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	INSERT INTO ba_data_history_buffers
	(
	bah_unique_code, bah_operation,
	bah_item_before, bah_item_after,
	bah_data_before, bah_data_after
	)
	VALUES
	(
		CASE WHEN TG_OP = 'INSERT'
			     THEN new.bad_unique_code
		     ELSE old.bad_unique_code END
	,   TG_OP
	,   CASE WHEN TG_OP = 'INSERT' THEN NULL ELSE to_jsonb(OLD) - 'bad_data' END
	,   CASE WHEN TG_OP = 'DELETE' THEN NULL ELSE to_jsonb(NEW) - 'bad_data' END
	,   CASE WHEN TG_OP = 'INSERT' THEN NULL ELSE to_jsonb(OLD.bad_data) END
	,   CASE WHEN TG_OP = 'DELETE' THEN NULL ELSE to_jsonb(NEW.bad_data) END
	);
	
	RETURN NULL;
END;
$$;

ALTER FUNCTION trigger_after_iud_ba_data() OWNER TO webapp;

