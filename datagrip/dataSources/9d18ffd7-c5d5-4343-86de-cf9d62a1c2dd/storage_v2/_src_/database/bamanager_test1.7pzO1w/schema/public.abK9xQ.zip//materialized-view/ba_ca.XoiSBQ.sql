CREATE MATERIALIZED VIEW ba_ca AS
WITH w1 AS (SELECT
	            ba_data.bad_unique_code                                                                     AS baca_company_unique_code
              , jsonb_array_elements(NULLIF(ba_data.bad_data #> '{advertisements}'::TEXT[], 'null'::JSONB)) AS baca_data
            FROM ba_data
            WHERE ba_data.bad_type_code = 'company'::TEXT)
SELECT
	baca_company_unique_code
  , baca_data
  , baca_data ->> 'ca_unique_code'::TEXT                                            AS baca_unique_code
  , (COALESCE(baca_data ->> 'ca_is_public'::TEXT, '0'::TEXT)::INTEGER = 0)::INTEGER AS baca_is_disabled
FROM w1;

COMMENT ON MATERIALIZED VIEW ba_ca IS '[BA] マッチングニーズ';

ALTER MATERIALIZED VIEW ba_ca OWNER TO webapp;

CREATE UNIQUE INDEX ba_ca_baca_unique_code_idx
	ON ba_ca(baca_unique_code);

GRANT SELECT ON ba_ca TO koko_readonly_role2;

GRANT SELECT ON ba_ca TO data_platform_readonly_role;

