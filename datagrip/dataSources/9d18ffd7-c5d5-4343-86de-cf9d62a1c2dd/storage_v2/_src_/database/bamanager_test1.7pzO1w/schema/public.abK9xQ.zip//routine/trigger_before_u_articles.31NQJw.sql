CREATE FUNCTION trigger_before_u_articles() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.a_revision = nextval('revision_seq');
	NEW.a_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_articles() OWNER TO webapp;

