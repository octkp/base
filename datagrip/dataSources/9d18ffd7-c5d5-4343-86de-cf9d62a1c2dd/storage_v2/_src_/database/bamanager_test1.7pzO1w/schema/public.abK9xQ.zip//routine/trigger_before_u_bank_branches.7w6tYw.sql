CREATE FUNCTION trigger_before_u_bank_branches() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.bb_revision = nextval('revision_seq');
	NEW.bb_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_bank_branches() OWNER TO webapp;

