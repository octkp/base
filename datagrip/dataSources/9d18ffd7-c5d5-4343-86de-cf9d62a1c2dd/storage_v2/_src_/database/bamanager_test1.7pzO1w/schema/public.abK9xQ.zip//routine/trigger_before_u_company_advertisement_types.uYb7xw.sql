CREATE FUNCTION trigger_before_u_company_advertisement_types() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.ca_type_revision = nextval('revision_seq');
	NEW.ca_type_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_company_advertisement_types() OWNER TO webapp;

