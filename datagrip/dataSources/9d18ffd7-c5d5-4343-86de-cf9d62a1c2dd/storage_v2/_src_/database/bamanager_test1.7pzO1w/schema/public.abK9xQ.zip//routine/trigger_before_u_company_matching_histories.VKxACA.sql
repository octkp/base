CREATE FUNCTION trigger_before_u_company_matching_histories() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.cmh_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_company_matching_histories() OWNER TO webapp;

