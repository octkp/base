CREATE FUNCTION trigger_before_u_companies() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.company_revision = nextval('revision_seq');
	NEW.company_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_companies() OWNER TO webapp;

