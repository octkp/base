CREATE FUNCTION trigger_before_u_company_registers() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.cr_revision = nextval('revision_seq');
	NEW.cr_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_company_registers() OWNER TO webapp;

