CREATE VIEW view_company_advertisements(ca_unique_code, ca_company_name, ca_updated_long_time_ago) AS
SELECT
	company_advertisements.ca_unique_code
  , companies.company_name                                AS ca_company_name
  , company_advertisements.ca_is_alive_confirm_target = 1 AS ca_updated_long_time_ago
FROM company_advertisements
JOIN companies ON companies.company_unique_code = company_advertisements.ca_company_unique_code;

ALTER TABLE view_company_advertisements
	OWNER TO webapp;

GRANT SELECT ON view_company_advertisements TO koko_readonly_role2;

GRANT SELECT ON view_company_advertisements TO data_platform_readonly_role;

