CREATE VIEW view_users
			( user_unique_code, user_bank_unique_code, user_bank_code, user_bank_name
			, user_profile_picture_file_unique_code, user_company_type, user_company_name
			)
AS
SELECT
	users.user_unique_code
  , banks.bank_unique_code                                  AS user_bank_unique_code
  , banks.bank_code                                         AS user_bank_code
  , banks.bank_name                                         AS user_bank_name
  , users.user_profile_picture ->> 'file_unique_code'::TEXT AS user_profile_picture_file_unique_code
  , companies.company_type                                  AS user_company_type
  , companies.company_name                                  AS user_company_name
FROM users
JOIN banks ON users.user_bank_code = banks.bank_code
LEFT JOIN companies ON companies.company_unique_code = users.user_company_unique_code;

ALTER TABLE view_users
	OWNER TO webapp;

GRANT SELECT ON view_users TO koko_readonly_role2;

GRANT SELECT ON view_users TO data_platform_readonly_role;

