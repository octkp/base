CREATE FUNCTION trigger_before_u_company_ca_favorites() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.ccf_revision = nextval('revision_seq');
	NEW.ccf_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_company_ca_favorites() OWNER TO webapp;

