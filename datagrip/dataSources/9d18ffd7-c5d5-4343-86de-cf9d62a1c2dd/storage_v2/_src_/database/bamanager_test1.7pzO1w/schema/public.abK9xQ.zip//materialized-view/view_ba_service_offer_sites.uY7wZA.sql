CREATE MATERIALIZED VIEW view_ba_service_offer_sites AS
WITH w1 AS (SELECT
	            t_cso.cso_data ->> 'cso_unique_code'::TEXT         AS cso_unique_code
              , t_cso.cso_data ->> 'csos_unique_code'::TEXT        AS csos_unique_code
              , (t_cso.cso_data ->> 'csos_seq'::TEXT)::INTEGER     AS csos_seq
              , t_cso.cso_data ->> 'csos_title'::TEXT              AS csos_title
              , t_cso.cso_data ->> 'csos_address_postcode_1'::TEXT AS csos_address_postcode_1
              , t_cso.cso_data ->> 'csos_address_postcode_2'::TEXT AS csos_address_postcode_2
              , t_cso.cso_data ->> 'csos_address_pref_name'::TEXT  AS csos_address_pref_name
              , t_cso.cso_data ->> 'csos_address_line_1'::TEXT     AS csos_address_line_1
              , t_cso.cso_data ->> 'csos_address_line_2'::TEXT     AS csos_address_line_2
              , t_cso.cso_data ->> 'csos_address_latitude'::TEXT   AS csos_address_latitude
              , t_cso.cso_data ->> 'csos_address_longitude'::TEXT  AS csos_address_longitude
              , t_cso.cso_data ->> 'csos_tel'::TEXT                AS csos_tel
              , t_cso.cso_data ->> 'csos_business_hours'::TEXT     AS csos_business_hours
              , t_cso.cso_data ->> 'csos_regular_holiday'::TEXT    AS csos_regular_holiday
              , t_cso.cso_data ->> 'csos_access'::TEXT             AS csos_access
              , t_cso.cso_data ->> 'csos_url'::TEXT                AS csos_url
              , (t_cso.cso_data ->> 'cso_limit_date'::TEXT)::DATE  AS csos_cso_limit_date
              , t_cso.cso_data                                     AS csos_cso_data
              , t_cso.company
              , t_cso.bank_code
            FROM (SELECT
	                  jsonb_array_elements(ba_data.bad_data -> 'service_offers'::TEXT) AS cso_data
                    , view_ba_companies_old.bacompany_data                             AS company
                    , view_ba_companies_old.bacompany_bank_code                        AS bank_code
                  FROM ba_data
                  JOIN view_ba_companies_old ON view_ba_companies_old.bacompany_unique_code = ba_data.bad_unique_code
                  WHERE ba_data.bad_type_code = 'company'::TEXT
	                AND (ba_data.bad_data ->> 'service_offers'::TEXT) IS NOT NULL) t_cso
            WHERE (t_cso.cso_data ->> 'cso_unique_code'::TEXT) IS NOT NULL
	          AND (t_cso.cso_data ->> 'csos_unique_code'::TEXT) IS NOT NULL
	          AND (t_cso.company ->> 'company_status'::TEXT) = 'ENABLE'::TEXT
	          AND (t_cso.cso_data ->> 'cso_type'::TEXT) = '2'::TEXT
            ORDER BY (t_cso.cso_data ->> 'cso_unique_code'::TEXT), (t_cso.cso_data ->> 'csos_unique_code'::TEXT)
                   , ((t_cso.cso_data ->> 'csos_seq'::TEXT)::INTEGER))
SELECT
	cso_unique_code
  , csos_unique_code
  , csos_seq
  , csos_title
  , csos_address_postcode_1
  , csos_address_postcode_2
  , csos_address_pref_name
  , csos_address_line_1
  , csos_address_line_2
  , csos_address_latitude
  , csos_address_longitude
  , csos_tel
  , csos_business_hours
  , csos_regular_holiday
  , csos_access
  , csos_url
  , csos_cso_limit_date
  , csos_cso_data
  , company
  , bank_code
  , COALESCE(csos_address_postcode_1, ''::TEXT) ||
    COALESCE('-'::TEXT || NULLIF(csos_address_postcode_2, ''::TEXT), ''::TEXT) AS csos_address_postcode
  , (COALESCE(csos_address_pref_name, ''::TEXT) || COALESCE(csos_address_line_1, ''::TEXT)) ||
    COALESCE(csos_address_line_2, ''::TEXT)                                    AS csos_address
FROM w1;

ALTER MATERIALIZED VIEW view_ba_service_offer_sites OWNER TO webapp;

CREATE UNIQUE INDEX view_ba_service_offer_sites_csos_unique_code_idx
	ON view_ba_service_offer_sites(csos_unique_code);

GRANT SELECT ON view_ba_service_offer_sites TO koko_readonly_role2;

GRANT SELECT ON view_ba_service_offer_sites TO data_platform_readonly_role;

