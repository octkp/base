CREATE FUNCTION trigger_before_u_register_reasons() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.rr_revision = nextval('revision_seq');
	NEW.rr_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_register_reasons() OWNER TO webapp;

