CREATE FUNCTION trigger_before_u_chat_remarks() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.chatremark_revision = nextval('revision_seq');
	NEW.chatremark_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_chat_remarks() OWNER TO webapp;

