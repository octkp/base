CREATE FUNCTION trigger_before_u_changelogs() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.cl_revision = nextval('revision_seq');
	NEW.cl_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_changelogs() OWNER TO webapp;

