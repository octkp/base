CREATE FUNCTION trigger_before_u_bidding_items() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.bi_revision = nextval('revision_seq');
	NEW.bi_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_bidding_items() OWNER TO webapp;

