CREATE FUNCTION trigger_before_u_company_advertisements() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.ca_revision = nextval('revision_seq');
	NEW.ca_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_company_advertisements() OWNER TO webapp;

