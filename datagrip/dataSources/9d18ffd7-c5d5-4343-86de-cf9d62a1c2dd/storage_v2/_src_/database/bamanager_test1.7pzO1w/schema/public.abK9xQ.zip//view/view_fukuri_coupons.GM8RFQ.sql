CREATE VIEW view_fukuri_coupons(fc_id, fc_sites_count) AS
SELECT
	fukuri_coupons.fc_id
  , t_sites.fc_sites_count
FROM fukuri_coupons
LEFT JOIN (SELECT
	           fukuri_coupon_sites.fcs_fc_unique_code AS fc_unique_code
             , count(*)                               AS fc_sites_count
           FROM fukuri_coupon_sites
           GROUP BY fukuri_coupon_sites.fcs_fc_unique_code) t_sites USING (fc_unique_code);

ALTER TABLE view_fukuri_coupons
	OWNER TO webapp;

GRANT SELECT ON view_fukuri_coupons TO koko_readonly_role2;

GRANT SELECT ON view_fukuri_coupons TO data_platform_readonly_role;

