CREATE MATERIALIZED VIEW view_ba_companies_old AS
SELECT
	ba_data.bad_unique_code                                                 AS bacompany_unique_code
  , ba_data.bad_revision                                                    AS bacompany_revision
  , banks.bank_code                                                         AS bacompany_bank_code
  , banks.bank_name                                                         AS bacompany_bank_name
  , ba_data.bad_data #>> '{company,company_name}'::TEXT[]                   AS bacompany_name
  , (ba_data.bad_data #>> '{company,company_is_partner}'::TEXT[])::INTEGER  AS bacompany_is_partner
  , (ba_data.bad_data #>> '{company,company_is_disabled}'::TEXT[])::INTEGER AS bacompany_is_disabled
  , ba_data.bad_data -> 'company'::TEXT                                     AS bacompany_data
FROM ba_data
JOIN banks ON banks.bank_code = ba_data.bad_src_bank_code
WHERE ba_data.bad_type_code = 'company'::TEXT;

COMMENT ON MATERIALIZED VIEW view_ba_companies_old IS '[BA] 企業';

ALTER MATERIALIZED VIEW view_ba_companies_old OWNER TO webapp;

CREATE UNIQUE INDEX view_ba_companies_bacompany_unique_code_idx
	ON view_ba_companies_old(bacompany_unique_code);

GRANT SELECT ON view_ba_companies_old TO koko_readonly_role2;

GRANT SELECT ON view_ba_companies_old TO data_platform_readonly_role;

