CREATE VIEW view_company_ca_favorites
			( ccf_unique_code, ccf_fav_ca_type_unique_code, ccf_fav_ca_type_name, ccf_fav_ca_id, ccf_fav_ca_body
			, ccf_fav_ca_partner_business_type, ccf_fav_ca_partner_requirement, ccf_fav_ca_created_at
			, ccf_company_origin_company_id, ccf_company_name, ccf_company_type, ccf_company_is_partner
			, ccf_company_enable_baportal, ccf_company_enable_ba, ccf_bank_name, ccf_bb_origin_bb_id, ccf_bb_code
			, ccf_bb_name, ccf_bb_unique_code, ccf_fav_company_origin_company_id, ccf_fav_company_type
			, ccf_fav_company_is_partner, ccf_fav_is_domestic, ccf_fav_company_enable_baportal
			, ccf_fav_company_enable_ba, ccf_fav_bank_name, ccf_fav_bb_code, ccf_fav_bb_name
			)
AS
SELECT
	company_ca_favorites.ccf_unique_code
  , company_advertisements.ca_type_unique_code                                    AS ccf_fav_ca_type_unique_code
  , company_advertisement_types.ca_type_name                                      AS ccf_fav_ca_type_name
  , company_advertisements.ca_origin_ca_id                                        AS ccf_fav_ca_id
  , company_advertisements.ca_body                                                AS ccf_fav_ca_body
  , company_advertisements.ca_partner_business_type                               AS ccf_fav_ca_partner_business_type
  , company_advertisements.ca_partner_requirement                                 AS ccf_fav_ca_partner_requirement
  , company_advertisements.ca_created_at                                          AS ccf_fav_ca_created_at
  , src_company.company_origin_company_id                                         AS ccf_company_origin_company_id
  , src_company.company_name                                                      AS ccf_company_name
  , src_company.company_type                                                      AS ccf_company_type
  , (src_company.company_type = 'partner'::TEXT)::INTEGER                         AS ccf_company_is_partner
  , src_company.company_enable_baportal                                           AS ccf_company_enable_baportal
  , src_company_type.company_enable_ba                                            AS ccf_company_enable_ba
  , src_bank.bank_name                                                            AS ccf_bank_name
  , src_bb.bb_origin_bb_id                                                        AS ccf_bb_origin_bb_id
  , src_bb.bb_code                                                                AS ccf_bb_code
  , src_bb.bb_name                                                                AS ccf_bb_name
  , src_bb.bb_unique_code                                                         AS ccf_bb_unique_code
  , dst_company.company_origin_company_id                                         AS ccf_fav_company_origin_company_id
  , dst_company.company_type                                                      AS ccf_fav_company_type
  , (dst_company.company_type = 'partner'::TEXT)::INTEGER                         AS ccf_fav_company_is_partner
  , (dst_company.company_bank_code = company_ca_favorites.ccf_bank_code)::INTEGER AS ccf_fav_is_domestic
  , dst_company.company_enable_baportal                                           AS ccf_fav_company_enable_baportal
  , dst_company_type.company_enable_ba                                            AS ccf_fav_company_enable_ba
  , dst_bank.bank_name                                                            AS ccf_fav_bank_name
  , dst_bb.bb_code                                                                AS ccf_fav_bb_code
  , dst_bb.bb_name                                                                AS ccf_fav_bb_name
FROM company_ca_favorites
JOIN companies src_company ON src_company.company_unique_code = company_ca_favorites.ccf_company_unique_code
JOIN company_types src_company_type ON src_company_type.company_type = src_company.company_type
JOIN banks src_bank ON src_bank.bank_code = src_company.company_bank_code
LEFT JOIN bank_branches src_bb ON src_bb.bb_unique_code = src_company.company_bb_unique_code
JOIN company_advertisements ON company_advertisements.ca_unique_code = company_ca_favorites.ccf_fav_ca_unique_code
JOIN company_advertisement_types USING (ca_type_unique_code)
JOIN companies dst_company ON dst_company.company_unique_code = company_advertisements.ca_company_unique_code
JOIN company_types dst_company_type ON dst_company_type.company_type = dst_company.company_type
JOIN banks dst_bank ON dst_bank.bank_code = dst_company.company_bank_code
LEFT JOIN bank_branches dst_bb ON dst_bb.bb_unique_code = dst_company.company_bb_unique_code;

ALTER TABLE view_company_ca_favorites
	OWNER TO webapp;

GRANT SELECT ON view_company_ca_favorites TO koko_readonly_role2;

GRANT SELECT ON view_company_ca_favorites TO data_platform_readonly_role;

