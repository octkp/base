CREATE FUNCTION latitude(earth) RETURNS double precision
	IMMUTABLE
	STRICT
	PARALLEL SAFE
	LANGUAGE sql
AS
$$SELECT CASE WHEN cube_ll_coord($1, 3)/earth() < -1 THEN -90::float8 WHEN cube_ll_coord($1, 3)/earth() > 1 THEN 90::float8 ELSE degrees(asin(cube_ll_coord($1, 3)/earth())) END$$;

ALTER FUNCTION latitude(EARTH) OWNER TO rdsadmin;

