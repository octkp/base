CREATE FUNCTION trigger_before_u_company_creditcards() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.cc_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_company_creditcards() OWNER TO webapp;

