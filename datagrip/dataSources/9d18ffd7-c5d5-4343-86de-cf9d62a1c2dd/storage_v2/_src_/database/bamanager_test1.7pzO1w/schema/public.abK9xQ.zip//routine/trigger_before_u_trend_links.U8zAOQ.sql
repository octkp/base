CREATE FUNCTION trigger_before_u_trend_links() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.tl_revision = nextval('revision_seq');
	NEW.tl_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_trend_links() OWNER TO webapp;

