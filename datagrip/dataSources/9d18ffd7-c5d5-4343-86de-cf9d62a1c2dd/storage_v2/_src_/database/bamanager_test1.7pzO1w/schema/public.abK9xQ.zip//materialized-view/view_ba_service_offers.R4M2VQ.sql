CREATE MATERIALIZED VIEW view_ba_service_offers AS
SELECT DISTINCT ON (view_ba_service_offer_sites.cso_unique_code)
	view_ba_service_offer_sites.cso_unique_code
  , view_ba_service_offer_sites.company ->> 'company_unique_code'::TEXT                 AS company_unique_code
  , view_ba_service_offer_sites.bank_code
  , view_ba_service_offer_sites.csos_cso_data ->> 'cso_category_unique_code'::TEXT      AS cso_category_unique_code
  , view_ba_service_offer_sites.csos_cso_data ->> 'cso_category_code'::TEXT             AS cso_category_code
  , view_ba_service_offer_sites.csos_cso_data ->> 'cso_category_name'::TEXT             AS cso_category_name
  , view_ba_service_offer_sites.csos_cso_data ->> 'cso_offer_url'::TEXT                 AS cso_offer_url
  , (view_ba_service_offer_sites.csos_cso_data ->> 'cso_type'::TEXT)::INTEGER           AS cso_type
  , view_ba_service_offer_sites.csos_cso_data ->> 'cso_status'::TEXT                    AS cso_status
  , (view_ba_service_offer_sites.csos_cso_data ->> 'cso_limit_date'::TEXT)::DATE        AS cso_limit_date
  , view_ba_service_offer_sites.csos_cso_data ->> 'cso_message'::TEXT                   AS cso_message
  , view_ba_service_offer_sites.csos_cso_data ->> 'cso_catch_copy'::TEXT                AS cso_catch_copy
  , (view_ba_service_offer_sites.csos_cso_data ->> 'cso_is_recommended'::TEXT)::INTEGER AS cso_is_recommended
  , view_ba_service_offer_sites.csos_cso_data ->> 'cso_note'::TEXT                      AS cso_note
  , j_csos.cso_sites
  , view_ba_service_offer_sites.csos_cso_data                                           AS cso_data
  , view_ba_service_offer_sites.csos_unique_code                                        AS cso_csos_unique_code
  , view_ba_service_offer_sites.csos_title                                              AS cso_csos_title
  , view_ba_service_offer_sites.csos_address_postcode                                   AS cso_csos_address_postcode
  , view_ba_service_offer_sites.csos_address_postcode_1                                 AS cso_csos_address_postcode_1
  , view_ba_service_offer_sites.csos_address_postcode_2                                 AS cso_csos_address_postcode_2
  , view_ba_service_offer_sites.csos_address                                            AS cso_csos_address
  , view_ba_service_offer_sites.csos_address_pref_name                                  AS cso_csos_address_pref_name
  , view_ba_service_offer_sites.csos_address_line_1                                     AS cso_csos_address_line_1
  , view_ba_service_offer_sites.csos_address_line_2                                     AS cso_csos_address_line_2
  , view_ba_service_offer_sites.csos_tel                                                AS cso_csos_tel
  , view_ba_service_offer_sites.csos_business_hours                                     AS cso_csos_business_hours
  , view_ba_service_offer_sites.csos_regular_holiday                                    AS cso_csos_regular_holiday
  , view_ba_service_offer_sites.csos_access                                             AS cso_csos_access
  , view_ba_service_offer_sites.csos_url                                                AS cso_csos_url
FROM view_ba_service_offer_sites
JOIN (SELECT
	      view_ba_service_offer_sites_1.cso_unique_code
        , jsonb_agg(view_ba_service_offer_sites_1.* ORDER BY view_ba_service_offer_sites_1.csos_seq) AS cso_sites
      FROM view_ba_service_offer_sites view_ba_service_offer_sites_1
      GROUP BY view_ba_service_offer_sites_1.cso_unique_code) j_csos USING (cso_unique_code)
WHERE view_ba_service_offer_sites.cso_unique_code IS NOT NULL
ORDER BY view_ba_service_offer_sites.cso_unique_code, view_ba_service_offer_sites.csos_seq;

COMMENT ON MATERIALIZED VIEW view_ba_service_offers IS '[BA] 福利厚生 提供サービス';

ALTER MATERIALIZED VIEW view_ba_service_offers OWNER TO webapp;

CREATE INDEX view_ba_service_offers_company_unique_code_idx
	ON view_ba_service_offers(company_unique_code);

CREATE UNIQUE INDEX view_ba_service_offers_cso_unique_code_idx
	ON view_ba_service_offers(cso_unique_code);

GRANT SELECT ON view_ba_service_offers TO koko_readonly_role2;

GRANT SELECT ON view_ba_service_offers TO data_platform_readonly_role;

