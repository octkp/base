CREATE VIEW view_articles (a_id, a_cover_image_file_unique_code, a_is_publishing, a_is_new_article) AS
SELECT
	articles.a_id
  , j_image_file.a_cover_image_file_unique_code
  , CASE
		WHEN articles.a_is_hidden = 0 AND articles.a_published_at <= now()
			THEN TRUE
		ELSE FALSE
		END AS a_is_publishing
  , CASE
		WHEN age(articles.a_published_at) < '1 day'::INTERVAL
			THEN TRUE
		ELSE FALSE
		END AS a_is_new_article
FROM articles
LEFT JOIN (SELECT
	           files.file_id          AS a_cover_image_file_id
             , files.file_unique_code AS a_cover_image_file_unique_code
           FROM files) j_image_file USING (a_cover_image_file_id);

ALTER TABLE view_articles
	OWNER TO webapp;

GRANT SELECT ON view_articles TO koko_readonly_role2;

GRANT SELECT ON view_articles TO data_platform_readonly_role;

