CREATE VIEW view_trend_links(tl_id, tl_cover_image_file_unique_code) AS
SELECT
	trend_links.tl_id
  , j_image_file.tl_cover_image_file_unique_code
FROM trend_links
LEFT JOIN (SELECT
	           files.file_id          AS tl_cover_image_file_id
             , files.file_unique_code AS tl_cover_image_file_unique_code
           FROM files) j_image_file USING (tl_cover_image_file_id);

ALTER TABLE view_trend_links
	OWNER TO webapp;

GRANT SELECT ON view_trend_links TO koko_readonly_role2;

GRANT SELECT ON view_trend_links TO data_platform_readonly_role;

