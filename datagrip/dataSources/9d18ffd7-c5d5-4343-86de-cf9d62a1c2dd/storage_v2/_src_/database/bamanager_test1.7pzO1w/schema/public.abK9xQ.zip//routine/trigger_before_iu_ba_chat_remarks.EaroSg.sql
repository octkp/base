CREATE FUNCTION trigger_before_iu_ba_chat_remarks() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.baremark_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_iu_ba_chat_remarks() OWNER TO webapp;

