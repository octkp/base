CREATE VIEW view_ba_interbank_partner_chat_rooms
			( bachatroom_id, bachatroom_bank_name, bachatroom_bank_is_disabled, bachatroom_company_name
			, bachatroom_company_bank_code, bachatroom_company_is_disabled, bachatroom_company_bank_is_disabled
			, bachatroom_company_bank_name, bachatroom_company_bb_code, bachatroom_company_bb_name
			, bachatroom_company_user_name, bachatroom_company_user_type_name, bachatroom_company_user_is_disabled
			, bachatroom_lastremark_created_at, bachatroom_lastremark_body, bachatroom_is_available
			)
AS
SELECT
	ba_interbank_partner_chat_rooms.bachatroom_id
  , banks.bank_name                       AS bachatroom_bank_name
  , banks.bank_is_disabled                AS bachatroom_bank_is_disabled
  , companies.company_name                AS bachatroom_company_name
  , companies.company_bank_code           AS bachatroom_company_bank_code
  , company_statuses.company_is_disabled  AS bachatroom_company_is_disabled
  , company_bank.bank_is_disabled         AS bachatroom_company_bank_is_disabled
  , company_bank.bank_name                AS bachatroom_company_bank_name
  , company_bb.bb_code                    AS bachatroom_company_bb_code
  , company_bb.bb_name                    AS bachatroom_company_bb_name
  , users.user_name                       AS bachatroom_company_user_name
  , user_types.user_type_name             AS bachatroom_company_user_type_name
  , users.user_is_disabled                AS bachatroom_company_user_is_disabled
  , ba_chat_remarks.baremark_created_at   AS bachatroom_lastremark_created_at
  , ba_chat_remarks.baremark_body         AS bachatroom_lastremark_body
  , (banks.bank_is_disabled = 0 AND company_bank.bank_is_disabled = 0 AND company_statuses.company_is_disabled = 0 AND
     users.user_is_disabled = 0)::INTEGER AS bachatroom_is_available
FROM ba_interbank_partner_chat_rooms
JOIN banks ON banks.bank_code = ba_interbank_partner_chat_rooms.bachatroom_bank_code
JOIN companies ON companies.company_unique_code = ba_interbank_partner_chat_rooms.bachatroom_company_unique_code
JOIN company_statuses USING (company_status)
JOIN banks company_bank ON company_bank.bank_code = companies.company_bank_code
LEFT JOIN bank_branches company_bb ON company_bb.bb_unique_code = companies.company_bb_unique_code
JOIN users ON users.user_unique_code = ba_interbank_partner_chat_rooms.bachatroom_company_user_unique_code
JOIN user_types USING (user_type)
LEFT JOIN ba_chat_remarks
          ON ba_chat_remarks.baremark_unique_code = ba_interbank_partner_chat_rooms.bachatroom_lastremark_unique_code;

COMMENT ON COLUMN view_ba_interbank_partner_chat_rooms.bachatroom_is_available IS 'ユーザーに表示可能(対向ともに有効)';

ALTER TABLE view_ba_interbank_partner_chat_rooms
	OWNER TO webapp;

GRANT SELECT ON view_ba_interbank_partner_chat_rooms TO koko_readonly_role2;

GRANT SELECT ON view_ba_interbank_partner_chat_rooms TO data_platform_readonly_role;

