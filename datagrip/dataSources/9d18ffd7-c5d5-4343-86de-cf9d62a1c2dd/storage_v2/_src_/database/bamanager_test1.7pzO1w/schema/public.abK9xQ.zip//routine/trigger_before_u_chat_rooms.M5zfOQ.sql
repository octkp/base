CREATE FUNCTION trigger_before_u_chat_rooms() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.chatroom_revision = nextval('revision_seq');
	NEW.chatroom_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_chat_rooms() OWNER TO webapp;

