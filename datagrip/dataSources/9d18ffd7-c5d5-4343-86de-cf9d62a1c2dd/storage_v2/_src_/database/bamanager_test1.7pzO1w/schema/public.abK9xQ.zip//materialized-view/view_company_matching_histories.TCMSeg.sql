CREATE MATERIALIZED VIEW view_company_matching_histories AS
SELECT
	company_matching_histories.cmh_unique_code
  , (destination_bank.bank_code = company_matching_histories.cmh_bank_code)::INTEGER AS cmh_is_domestic
  , company_advertisements.ca_type_unique_code                                       AS cmh_destination_ca_type_unique_code
  , company_advertisement_types.ca_type_name                                         AS cmh_destination_ca_type_name
  , company_advertisements.ca_title                                                  AS cmh_destination_ca_title
  , attendant_user.user_name                                                         AS cmh_attendant_user_name
  , requester_company.company_name                                                   AS cmh_requester_company_name
  , requester_company.company_status                                                 AS cmh_requester_company_status
  , requester_company_status.company_is_disabled                                     AS cmh_requester_company_is_disabled
  , requester_company.company_bank_code                                              AS cmh_requester_bank_code
  , requester_bank.bank_name                                                         AS cmh_requester_bank_name
  , requester_bank_branch.bb_unique_code                                             AS cmh_requester_bb_unique_code
  , requester_bank_branch.bb_code                                                    AS cmh_requester_bb_code
  , requester_bank_branch.bb_name                                                    AS cmh_requester_bb_name
  , requester_user.user_unique_code                                                  AS cmh_requester_user_unique_code
  , requester_user.user_name                                                         AS cmh_requester_user_name
  , (requester_company.company_type = 'partner'::TEXT)::INTEGER                      AS cmh_requester_company_is_partner
  , destination_company.company_name                                                 AS cmh_destination_company_name
  , destination_company.company_status                                               AS cmh_destination_company_status
  , destination_company_status.company_is_disabled                                   AS cmh_destination_company_is_disabled
  , destination_bank.bank_name                                                       AS cmh_destination_bank_name
  , destination_bank_branch.bb_unique_code                                           AS cmh_destination_bb_unique_code
  , destination_bank_branch.bb_code                                                  AS cmh_destination_bb_code
  , destination_bank_branch.bb_name                                                  AS cmh_destination_bb_name
  , (destination_company.company_type = 'partner'::TEXT)::INTEGER                    AS cmh_destination_company_is_partner
  , destination_company.company_origin_company_id                                    AS cmh_origin_destination_company_id
FROM company_matching_histories
JOIN company_advertisements
     ON company_advertisements.ca_unique_code = company_matching_histories.cmh_destination_ca_unique_code
JOIN company_advertisement_types USING (ca_type_unique_code)
LEFT JOIN users attendant_user
          ON attendant_user.user_unique_code = company_matching_histories.cmh_attendant_user_unique_code
JOIN companies requester_company
     ON requester_company.company_unique_code = company_matching_histories.cmh_requester_company_unique_code
JOIN company_statuses requester_company_status
     ON requester_company_status.company_status = requester_company.company_status
JOIN banks requester_bank ON requester_bank.bank_code = requester_company.company_bank_code
LEFT JOIN bank_branches requester_bank_branch
          ON requester_bank_branch.bb_unique_code = requester_company.company_bb_unique_code
LEFT JOIN users requester_user
          ON requester_user.user_unique_code = company_matching_histories.cmh_requester_user_unique_code
JOIN companies destination_company
     ON destination_company.company_unique_code = company_matching_histories.cmh_destination_company_unique_code
JOIN company_statuses destination_company_status
     ON destination_company_status.company_status = destination_company.company_status
JOIN banks destination_bank ON destination_bank.bank_code = destination_company.company_bank_code
LEFT JOIN bank_branches destination_bank_branch
          ON destination_bank_branch.bb_unique_code = destination_company.company_bb_unique_code;

ALTER MATERIALIZED VIEW view_company_matching_histories OWNER TO webapp;

CREATE INDEX view_company_matching_histori_cmh_destination_bb_unique_cod_idx
	ON view_company_matching_histories(cmh_destination_bb_unique_code);

CREATE INDEX view_company_matching_histori_cmh_destination_ca_type_uniqu_idx
	ON view_company_matching_histories(cmh_destination_ca_type_unique_code);

CREATE INDEX view_company_matching_histori_cmh_destination_company_is_di_idx
	ON view_company_matching_histories(cmh_destination_company_is_disabled);

CREATE INDEX view_company_matching_histori_cmh_destination_company_is_pa_idx
	ON view_company_matching_histories(cmh_destination_company_is_partner);

CREATE INDEX view_company_matching_histori_cmh_origin_destination_compan_idx
	ON view_company_matching_histories(cmh_origin_destination_company_id);

CREATE INDEX view_company_matching_histori_cmh_requester_company_is_disa_idx
	ON view_company_matching_histories(cmh_requester_company_is_disabled);

CREATE INDEX view_company_matching_histori_cmh_requester_company_is_part_idx
	ON view_company_matching_histories(cmh_requester_company_is_partner);

CREATE INDEX view_company_matching_histori_cmh_requester_user_unique_cod_idx
	ON view_company_matching_histories(cmh_requester_user_unique_code);

CREATE INDEX view_company_matching_historie_cmh_requester_bb_unique_code_idx
	ON view_company_matching_histories(cmh_requester_bb_unique_code);

CREATE INDEX view_company_matching_historie_cmh_requester_company_status_idx
	ON view_company_matching_histories(cmh_requester_company_status);

CREATE INDEX view_company_matching_histories_cmh_destination_bb_code_idx
	ON view_company_matching_histories(cmh_destination_bb_code);

CREATE INDEX view_company_matching_histories_cmh_requester_bank_code_idx
	ON view_company_matching_histories(cmh_requester_bank_code);

CREATE INDEX view_company_matching_histories_cmh_requester_bb_code_idx
	ON view_company_matching_histories(cmh_requester_bb_code);

CREATE UNIQUE INDEX view_company_matching_histories_cmh_unique_code_idx
	ON view_company_matching_histories(cmh_unique_code);

GRANT SELECT ON view_company_matching_histories TO koko_readonly_role2;

GRANT SELECT ON view_company_matching_histories TO data_platform_readonly_role;

