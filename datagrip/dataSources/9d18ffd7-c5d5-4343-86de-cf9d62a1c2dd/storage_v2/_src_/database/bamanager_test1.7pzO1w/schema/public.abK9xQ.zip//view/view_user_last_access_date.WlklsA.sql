CREATE VIEW view_user_last_access_date(ulad_user_unique_code, ulad_date, ulad_time) AS
SELECT DISTINCT ON (udah_user_unique_code)
	udah_user_unique_code AS ulad_user_unique_code
  , udah_date             AS ulad_date
  , udah_time             AS ulad_time
FROM user_daily_access_history
WHERE udah_user_unique_code IS NOT NULL
ORDER BY udah_user_unique_code, udah_date DESC;

ALTER TABLE view_user_last_access_date
	OWNER TO webapp;

GRANT SELECT ON view_user_last_access_date TO koko_readonly_role2;

GRANT SELECT ON view_user_last_access_date TO data_platform_readonly_role;

