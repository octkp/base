CREATE FUNCTION longitude(earth) RETURNS double precision
	IMMUTABLE
	STRICT
	PARALLEL SAFE
	LANGUAGE sql
AS
$$SELECT degrees(atan2(cube_ll_coord($1, 2), cube_ll_coord($1, 1)))$$;

ALTER FUNCTION longitude(EARTH) OWNER TO rdsadmin;

