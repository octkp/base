CREATE VIEW pg_stat_statements_info(dealloc, stats_reset) AS
SELECT
	dealloc
  , stats_reset
FROM pg_stat_statements_info() pg_stat_statements_info(dealloc, stats_reset);

ALTER TABLE pg_stat_statements_info
	OWNER TO rdsadmin;

GRANT SELECT ON pg_stat_statements_info TO PUBLIC;

