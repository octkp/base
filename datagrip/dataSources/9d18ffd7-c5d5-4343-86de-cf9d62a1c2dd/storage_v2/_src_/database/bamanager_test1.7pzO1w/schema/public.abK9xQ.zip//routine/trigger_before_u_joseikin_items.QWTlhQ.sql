CREATE FUNCTION trigger_before_u_joseikin_items() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.ji_revision = nextval('revision_seq');
	NEW.ji_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_joseikin_items() OWNER TO webapp;

