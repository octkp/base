CREATE FUNCTION trigger_before_iu_ba_data() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	new.bad_updated_at = now();
	new.bad_revision = nextval('revision_seq');
	
	RETURN new;
END;
$$;

ALTER FUNCTION trigger_before_iu_ba_data() OWNER TO webapp;

