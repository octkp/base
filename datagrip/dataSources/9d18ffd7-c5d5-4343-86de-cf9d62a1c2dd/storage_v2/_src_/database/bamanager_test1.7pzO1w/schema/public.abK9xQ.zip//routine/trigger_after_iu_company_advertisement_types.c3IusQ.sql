CREATE FUNCTION trigger_after_iu_company_advertisement_types() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	-- @formatter:off
	INSERT INTO updated_items (ui_unique_code,ui_revision) VALUES (NEW.ca_type_unique_code, NEW.ca_type_revision) on CONFLICT (ui_unique_code,ui_revision) do NOTHING;
	-- @formatter:on
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_after_iu_company_advertisement_types() OWNER TO webapp;

