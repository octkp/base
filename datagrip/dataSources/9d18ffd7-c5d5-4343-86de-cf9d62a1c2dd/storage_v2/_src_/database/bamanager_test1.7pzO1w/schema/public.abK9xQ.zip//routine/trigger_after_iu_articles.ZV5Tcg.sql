CREATE FUNCTION trigger_after_iu_articles() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	-- @formatter:off
	INSERT INTO updated_items (ui_unique_code,ui_revision) VALUES (NEW.a_unique_code, NEW.a_revision) on CONFLICT (ui_unique_code,ui_revision) do NOTHING;
	-- @formatter:on
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_after_iu_articles() OWNER TO webapp;

