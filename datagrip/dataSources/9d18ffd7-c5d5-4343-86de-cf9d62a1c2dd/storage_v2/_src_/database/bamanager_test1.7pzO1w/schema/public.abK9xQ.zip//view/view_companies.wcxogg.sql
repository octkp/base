CREATE VIEW view_companies
			( company_unique_code, company_bank_name, company_owner_user_unique_code, company_owner_user_name
			, company_owner_user_last_name, company_owner_user_first_name, company_owner_user_last_name_kana
			, company_owner_user_first_name_kana, company_owner_user_email, company_bb_code, company_bb_name
			, company_is_partner
			)
AS
SELECT
	companies.company_unique_code
  , banks.bank_name                                     AS company_bank_name
  , owner.user_unique_code                              AS company_owner_user_unique_code
  , owner.user_name                                     AS company_owner_user_name
  , owner.user_last_name                                AS company_owner_user_last_name
  , owner.user_first_name                               AS company_owner_user_first_name
  , owner.user_last_name_kana                           AS company_owner_user_last_name_kana
  , owner.user_first_name_kana                          AS company_owner_user_first_name_kana
  , owner.user_email                                    AS company_owner_user_email
  , bank_branches.bb_code                               AS company_bb_code
  , bank_branches.bb_name                               AS company_bb_name
  , (companies.company_type = 'partner'::TEXT)::INTEGER AS company_is_partner
FROM companies
LEFT JOIN users owner ON companies.company_owner_user_unique_code = owner.user_unique_code
LEFT JOIN bank_branches ON bank_branches.bb_unique_code = companies.company_bb_unique_code
JOIN banks ON banks.bank_code = companies.company_bank_code;

ALTER TABLE view_companies
	OWNER TO webapp;

GRANT SELECT ON view_companies TO koko_readonly_role2;

GRANT SELECT ON view_companies TO data_platform_readonly_role;

