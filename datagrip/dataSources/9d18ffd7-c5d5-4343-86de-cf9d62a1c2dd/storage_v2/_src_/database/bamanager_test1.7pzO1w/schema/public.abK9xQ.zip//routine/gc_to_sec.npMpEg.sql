CREATE FUNCTION gc_to_sec(double precision) RETURNS double precision
	IMMUTABLE
	STRICT
	PARALLEL SAFE
	LANGUAGE sql
AS
$$SELECT CASE WHEN $1 < 0 THEN 0::float8 WHEN $1/earth() > pi() THEN 2*earth() ELSE 2*earth()*sin($1/(2*earth())) END$$;

ALTER FUNCTION gc_to_sec(DOUBLE PRECISION) OWNER TO rdsadmin;

