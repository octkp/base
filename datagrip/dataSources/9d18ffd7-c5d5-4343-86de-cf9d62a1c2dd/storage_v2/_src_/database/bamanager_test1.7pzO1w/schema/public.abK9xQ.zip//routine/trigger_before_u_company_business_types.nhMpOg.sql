CREATE FUNCTION trigger_before_u_company_business_types() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.cbt_revision = nextval('revision_seq');
	NEW.cbt_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_company_business_types() OWNER TO webapp;

