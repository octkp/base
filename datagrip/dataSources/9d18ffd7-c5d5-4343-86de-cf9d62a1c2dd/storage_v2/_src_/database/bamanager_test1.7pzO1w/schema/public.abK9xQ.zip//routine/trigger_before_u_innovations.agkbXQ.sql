CREATE FUNCTION trigger_before_u_innovations() RETURNS trigger
	LANGUAGE plpgsql
AS
$$
BEGIN
	
	NEW.i_revision = nextval('revision_seq');
	NEW.i_updated_at = now();
	
	RETURN NEW;
END;
$$;

ALTER FUNCTION trigger_before_u_innovations() OWNER TO webapp;

