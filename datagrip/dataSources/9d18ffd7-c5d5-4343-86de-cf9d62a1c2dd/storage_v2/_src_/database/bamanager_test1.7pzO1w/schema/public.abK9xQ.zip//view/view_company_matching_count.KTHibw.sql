CREATE VIEW view_company_matching_count(company_unique_code, company_ca_count) AS
SELECT
	companies.company_unique_code
  , t_ca.ca_count AS company_ca_count
FROM companies
LEFT JOIN (SELECT
	           company_advertisements.ca_company_unique_code AS company_unique_code
             , count(*)                                      AS ca_count
           FROM company_advertisements
           WHERE company_advertisements.ca_deleted_at IS NULL
           GROUP BY company_advertisements.ca_company_unique_code) t_ca USING (company_unique_code);

ALTER TABLE view_company_matching_count
	OWNER TO webapp;

GRANT SELECT ON view_company_matching_count TO koko_readonly_role2;

GRANT SELECT ON view_company_matching_count TO data_platform_readonly_role;

