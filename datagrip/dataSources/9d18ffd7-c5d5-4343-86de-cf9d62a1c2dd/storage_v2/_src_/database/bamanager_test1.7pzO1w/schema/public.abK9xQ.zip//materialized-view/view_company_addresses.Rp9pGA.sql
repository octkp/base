CREATE MATERIALIZED VIEW view_company_addresses AS
SELECT
	company_unique_code
  , company_address_type
  , company_address
  , company_address ->> 'post_code_1'::TEXT AS company_address_post_code_1
  , company_address ->> 'post_code_2'::TEXT AS company_address_post_code_2
  , company_address ->> 'pref_name'::TEXT   AS company_address_pref_name
  , company_address ->> 'address_1'::TEXT   AS company_address_address_1
  , company_address ->> 'address_2'::TEXT   AS company_address_address_2
FROM (SELECT
	      companies.company_unique_code
        , 'main'::TEXT                                  AS company_address_type
        , companies.company_address #> '{main}'::TEXT[] AS company_address
      FROM companies
      UNION
      SELECT
	      companies.company_unique_code
        , 'sub'::TEXT                                                           AS company_address_type
        , jsonb_array_elements(companies.company_address #> '{branch}'::TEXT[]) AS company_address
      FROM companies) t_address
WHERE company_address IS NOT NULL;

ALTER MATERIALIZED VIEW view_company_addresses OWNER TO webapp;

CREATE INDEX view_company_addresses_company_unique_code_idx
	ON view_company_addresses(company_unique_code);

GRANT SELECT ON view_company_addresses TO koko_readonly_role2;

GRANT SELECT ON view_company_addresses TO data_platform_readonly_role;

