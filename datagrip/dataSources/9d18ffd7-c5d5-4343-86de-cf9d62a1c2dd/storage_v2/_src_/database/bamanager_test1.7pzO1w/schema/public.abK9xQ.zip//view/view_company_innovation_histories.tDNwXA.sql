CREATE VIEW view_company_innovation_histories
			( cih_id, cih_requester_bank_code, cih_requester_bank_unique_code, cih_requester_bank_name
			, cih_requester_company_unique_code, cih_requester_company_type, cih_requester_company_is_partner
			, cih_requester_company_name, cih_requester_company_origin_bb_id, cih_requester_company_bb_code
			, cih_requester_company_bb_unique_code, cih_requester_company_bb_name, cih_requester_user_unique_code
			, cih_requester_user_name, cih_destination_bank_unique_code, cih_destination_bank_name
			, cih_destination_company_unique_code, cih_destination_company_name, cih_destination_company_type
			, cih_destination_company_is_partner, cih_destination_company_origin_bb_id, cih_destination_company_bb_code
			, cih_destination_company_bb_unique_code, cih_destination_company_bb_name
			)
AS
SELECT
	company_innovation_histories.cih_id
  , requester_bank.bank_code                           AS cih_requester_bank_code
  , requester_bank.bank_unique_code                    AS cih_requester_bank_unique_code
  , requester_bank.bank_name                           AS cih_requester_bank_name
  , requester_company.company_unique_code              AS cih_requester_company_unique_code
  , requester_company.company_type                     AS cih_requester_company_type
  , requester_company.company_type = 'partner'::TEXT   AS cih_requester_company_is_partner
  , requester_company.company_name                     AS cih_requester_company_name
  , requester_bb.bb_origin_bb_id                       AS cih_requester_company_origin_bb_id
  , requester_bb.bb_code                               AS cih_requester_company_bb_code
  , requester_bb.bb_unique_code                        AS cih_requester_company_bb_unique_code
  , requester_bb.bb_name                               AS cih_requester_company_bb_name
  , requester_user.user_unique_code                    AS cih_requester_user_unique_code
  , requester_user.user_name                           AS cih_requester_user_name
  , destination_bank.bank_unique_code                  AS cih_destination_bank_unique_code
  , destination_bank.bank_name                         AS cih_destination_bank_name
  , destination_company.company_unique_code            AS cih_destination_company_unique_code
  , destination_company.company_name                   AS cih_destination_company_name
  , destination_company.company_type                   AS cih_destination_company_type
  , destination_company.company_type = 'partner'::TEXT AS cih_destination_company_is_partner
  , destination_bb.bb_origin_bb_id                     AS cih_destination_company_origin_bb_id
  , destination_bb.bb_code                             AS cih_destination_company_bb_code
  , destination_bb.bb_unique_code                      AS cih_destination_company_bb_unique_code
  , destination_bb.bb_name                             AS cih_destination_company_bb_name
FROM company_innovation_histories
LEFT JOIN companies requester_company
          ON requester_company.company_unique_code = company_innovation_histories.cih_requester_company_unique_code
LEFT JOIN users requester_user
          ON requester_user.user_unique_code = company_innovation_histories.cih_requester_user_unique_code
LEFT JOIN banks requester_bank ON requester_bank.bank_code = requester_user.user_bank_code
LEFT JOIN banks destination_bank ON destination_bank.bank_code = company_innovation_histories.cih_destination_bank_code
LEFT JOIN companies destination_company ON destination_company.company_unique_code =
                                           company_innovation_histories.cih_destination_bacompany_unique_code
LEFT JOIN bank_branches requester_bb ON requester_bb.bb_unique_code = requester_company.company_bb_unique_code
LEFT JOIN bank_branches destination_bb ON destination_bb.bb_unique_code = destination_company.company_bb_unique_code;

ALTER TABLE view_company_innovation_histories
	OWNER TO webapp;

GRANT SELECT ON view_company_innovation_histories TO koko_readonly_role2;

GRANT SELECT ON view_company_innovation_histories TO data_platform_readonly_role;

