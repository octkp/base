CREATE MATERIALIZED VIEW view_ba_chat_remark_stats AS
WITH w1 AS (SELECT
	            banks_1.bank_code
              , ba_chat_rooms.bachatroom_type
              , users.user_type
              , date_part('year'::TEXT, ba_chat_remarks.baremark_created_at)  AS baremark_created_at_year
              , date_part('month'::TEXT, ba_chat_remarks.baremark_created_at) AS baremark_created_at_month
              , count(*)                                                      AS remarks_count
            FROM ba_chat_remarks
            JOIN ba_chat_rooms ON ba_chat_rooms.bachatroom_unique_code = ba_chat_remarks.baremark_bachatroom_unique_code
            JOIN users ON users.user_unique_code = ba_chat_remarks.baremark_user_unique_code
            JOIN banks banks_1 ON banks_1.bank_code = users.user_bank_code
            GROUP BY banks_1.bank_code, ba_chat_rooms.bachatroom_type, users.user_type
                   , (date_part('year'::TEXT, ba_chat_remarks.baremark_created_at))
                   , (date_part('month'::TEXT, ba_chat_remarks.baremark_created_at)))
SELECT
	w1.bank_code                       AS bachatstat_bank_code
  , banks.bank_name                    AS bachatstat_bank_name
  , w1.bachatroom_type                 AS bachatstat_chatroom_type
  , chat_room_types.chatroom_type_name AS bachatstat_chatroom_type_name
  , w1.user_type                       AS bachatstat_user_type
  , user_types.user_type_name          AS bachatstat_user_type_name
  , user_types.user_type_group         AS bachatstat_user_type_group
  , w1.baremark_created_at_year        AS bachatstat_year
  , w1.baremark_created_at_month       AS bachatstat_month
  , w1.remarks_count                   AS bachatstat_remarks_count
  , now()                              AS bachatstat_created_at
FROM w1
JOIN banks USING (bank_code)
JOIN chat_room_types ON chat_room_types.chatroom_type = w1.bachatroom_type
JOIN user_types USING (user_type);

ALTER MATERIALIZED VIEW view_ba_chat_remark_stats OWNER TO webapp;

GRANT SELECT ON view_ba_chat_remark_stats TO koko_readonly_role2;

GRANT SELECT ON view_ba_chat_remark_stats TO data_platform_readonly_role;

