CREATE VIEW view_company_user_count
			(company_unique_code, company_member_count, company_business_user_count, company_employee_user_count) AS
SELECT
	user_company_unique_code                                     AS company_unique_code
  , count(*)                                                     AS company_member_count
  , count(*) FILTER (WHERE user_type = 'company_user'::TEXT)     AS company_business_user_count
  , count(*) FILTER (WHERE user_type = 'company_employee'::TEXT) AS company_employee_user_count
FROM users
WHERE user_company_unique_code IS NOT NULL
  AND user_is_disabled = 0
GROUP BY user_company_unique_code;

ALTER TABLE view_company_user_count
	OWNER TO webapp;

GRANT SELECT ON view_company_user_count TO koko_readonly_role2;

GRANT SELECT ON view_company_user_count TO data_platform_readonly_role;

